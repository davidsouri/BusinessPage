Free Shipping Filter Plugin

The Free Shipping Filter Plugin for WooCommerce allows online stores to enhance their customer experience by exclusively offering free shipping options when available, 
regardless of the cart total.

this plugin seamlessly integrates with WooCommerce to filter out all shipping methods except for free shipping if it's an option

Exclusive Free Shipping Display: Automatically filters and displays only the free shipping option when it is available, ignoring other shipping methods and the cart total.

Seamless WooCommerce Integration: Designed specifically for WooCommerce, ensuring compatibility and smooth integration.

Improved Shopping Experience: Encourages customers to complete purchases by simplifying shipping options and highlighting free shipping availability.

Installation

Download the Plugin: Download the freeshippingfilter100.php file from DavidSouri.com.
Upload and Activate: Upload the file to your WordPress site's wp-content/plugins directory and activate the plugin through the WordPress admin dashboard.
Automatic Operation: Once activated, the plugin automatically applies its filtering logic to shipping methods without any additional setup required.

Usage

After installation and activation, the Free Shipping Filter Plugin will automatically begin filtering shipping methods based on the availability of free shipping.
There's no need for further configuration.
When free shipping is available for a customer's cart, the plugin ensures that only the free shipping option is presented to the customer.

NO SUPPORT - USE AT YOUR OWN RISK 

Make a BACKUP of your site before installing the plug-in 

Plugin Name: Free Shipping Filter
Plugin URI: https://DavidSouri.com
Description: Filters shipping methods to exclusively show free shipping when it's available, regardless of the cart total.
Version: 1.0.0
Author: David Souri
Author URI: https://DavidSouri.com