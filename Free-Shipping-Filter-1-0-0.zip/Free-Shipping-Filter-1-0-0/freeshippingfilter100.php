<?php
/**
 * Plugin Name: Free Shipping Filter
 * Plugin URI: https://DavidSouri.com
 * Description: Filters shipping methods to exclusively show free shipping when it's available, regardless of the cart total.
 * Version: 1.0.0
 * Author: David Souri
 * Author URI: https://DavidSouri.com
 */

add_filter('woocommerce_package_rates', 'filter_shipping_methods_based_on_free_shipping_availability', 10, 2);

/**
 * Filters shipping methods to only show free shipping if it's available.
 * This function ignores the cart total and focuses solely on the availability of free shipping.
 *
 * @param array $rates An array of shipping rates.
 * @param array $package The package for which rates are being filtered.
 * @return array Filtered shipping rates.
 */
function filter_shipping_methods_based_on_free_shipping_availability($rates, $package) {
    $free_shipping_available = false;

    // Check if free shipping is available in the list of rates
    foreach ($rates as $rate_id => $rate) {
        if ('free_shipping' === $rate->method_id) {
            $free_shipping_available = true;
            break; // Stop the loop once free shipping is found
        }
    }

    // If free shipping is available, unset all other shipping methods
    if ($free_shipping_available) {
        foreach ($rates as $rate_id => $rate) {
            if ('free_shipping' !== $rate->method_id) {
                unset($rates[$rate_id]);
            }
        }
    }

    return $rates; // Return the potentially modified list of shipping rates
}
